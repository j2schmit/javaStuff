Use the supplied .java file(s) as the basis of your solution to the assignment. Note that, for the purposes of this course, all classes are defined within the default package (in other words, they do not explicitly specify a package).

This assignment must be submitted as a .zip file containing only your solution's .java files named following the convention LastnameFirstInitialExercise#.zip where the '#' is the Exercise number.
For example, my submission for this assignment would be named DukeGExercise6.25.zip). There should be NO DIRECTORIES within the zip file.


Expected program (FindPrimes) console (System.out) output:
Prime numbers < 10k:
2
3
5
7
11
13
... this goes on for quite some time. I won't list all of the primes identified and displayed by the program here, but your program should do so following the example/format above