/*
 * Shape.java
 */

/**
 *
 * @author Jeremy Schmitt
 */


public abstract class Shape {

	public abstract String getName();

}
