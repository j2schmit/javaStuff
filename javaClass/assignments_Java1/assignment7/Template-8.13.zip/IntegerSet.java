/*
 * IntegerSet.java
 */

/**
 *
 * @author StudentName
 */
public class IntegerSet {
    
    /** 
     * Creates a new instance of IntegerSet   
     */
    // TODO: implement the constructor
    
    /**
     * Return a new IntegerSet containing the union of the two IntegerSet objects
     * passed as arguments
     */
    // TODO: implement the union method
    
    /**
     * Return a new IntegerSet containing the intersection of the two IntegerSet objects
     * passed as arguments
     */
    // TODO: implement the intersection method
    
    /**
     * Inserts an element into the IntegerSet by setting the corresponding
     * value within the set array to true. Returns false if the value was out
     * of range and true otherwise.
     */
    // TODO: implement the insertElement method
    
    /**
     * Deletes an element from the IntegerSet by setting the corresponding
     * value within the set array to false. Returns false if the value was out
     * of range and true otherwise.
     */
    // TODO: implement the deleteElement method 
    
    /**
     * @Override the toString method in the Object class
     * Displays the integers contained by the IntegerSet separated by spaces. 
     * An empty set should be displayed as:
     * { --- }
     * An integer set containing 5 and 10 should be displayed as:
     * { 5 10 }
     */
    // TODO: implement the toString method   
    
    /**
     * Returns true iff the current IntegerSet contains the same integers as
     * the IntegerSet supplied as an argument
     */
	// TODO: implement the isEqualTo method         
}
